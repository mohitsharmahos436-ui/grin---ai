# ⚡ GRIN AI — The Omniscient Oracle

An AI-powered chat app using Claude + live web search, with a secure Node.js backend that keeps your API key safe.

---

## 📁 Project Structure

```
grin-ai/
├── server.js          ← Express backend (API key lives here)
├── package.json
├── .env.example       ← Copy to .env and add your key
├── .gitignore
└── public/
    └── index.html     ← Frontend (calls /api/chat, not Anthropic directly)
```

---

## 🚀 Deploy in 5 minutes — Railway (Recommended, Free)

1. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "GRIN AI launch"
   # Create a repo on github.com, then:
   git remote add origin https://github.com/YOUR_USERNAME/grin-ai.git
   git push -u origin main
   ```

2. **Go to [railway.app](https://railway.app)** → Sign in with GitHub → New Project → Deploy from GitHub repo → select `grin-ai`

3. **Add your API key**
   - In Railway dashboard → your project → Variables tab
   - Add: `ANTHROPIC_API_KEY` = `sk-ant-your-key-here`

4. **Done!** Railway gives you a live URL like `grin-ai-production.up.railway.app`

---

## 🌐 Deploy on Render (Also Free)

1. Push to GitHub (same steps as above)
2. Go to [render.com](https://render.com) → New → Web Service → connect your repo
3. Set:
   - **Build command:** `npm install`
   - **Start command:** `node server.js`
4. Under Environment → add `ANTHROPIC_API_KEY`
5. Deploy → get your live URL

---

## 💻 Run Locally

```bash
# 1. Install dependencies
npm install

# 2. Create your .env file
cp .env.example .env
# Edit .env and add your Anthropic API key

# 3. Start the server
npm start

# Open http://localhost:3000
```

---

## 🔑 Get Your Anthropic API Key

1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Sign up / log in
3. Go to API Keys → Create Key
4. Copy it into your `.env` or Railway/Render environment variable

---

## 🛡️ Security Features

- ✅ API key **never sent to the browser**
- ✅ Rate limiting: 20 requests per IP per minute
- ✅ Input validation and length limits
- ✅ No secrets in frontend code
